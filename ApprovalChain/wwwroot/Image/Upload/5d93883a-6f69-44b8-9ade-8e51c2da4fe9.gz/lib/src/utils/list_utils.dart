class AwesomeListUtils {
  static bool isNullOrEmpty(List? value) {
    return value?.isEmpty ?? true;
  }
}
