import 'package:flutter/material.dart';

class RemarkableDivisor extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Divider(
      color: Colors.black,
      height: 5,
    );
  }
}
