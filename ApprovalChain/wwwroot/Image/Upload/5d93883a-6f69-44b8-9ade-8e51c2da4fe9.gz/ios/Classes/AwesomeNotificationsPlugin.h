#import <Flutter/Flutter.h>

@interface AwesomeNotificationsPlugin : NSObject<FlutterPlugin>
@end
