public enum GroupAlertBehaviour : String, CaseIterable {
    
    case All = "All"
    case Summary = "Summary"
    case Children = "Children"
}
