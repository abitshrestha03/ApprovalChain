//
//  GroupSort.swift
//  awesome_notifications
//
//  Created by Rafael Setragni on 05/03/21.
//

public enum GroupSort : String, CaseIterable {
    
    case Asc = "Asc"
    case Desc = "Desc"
    
}
