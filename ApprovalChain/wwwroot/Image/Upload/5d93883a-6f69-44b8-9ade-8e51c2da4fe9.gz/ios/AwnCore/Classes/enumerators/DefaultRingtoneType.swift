//
//  DefaultRingtoneType.swift
//  awesome_notifications
//
//  Created by Rafael Setragni on 05/03/21.
//

public enum DefaultRingtoneType : String, CaseIterable {
    
    case Ringtone = "Ringtone"
    case Notification = "Notification"
    case Alarm = "Alarm"
    
}
