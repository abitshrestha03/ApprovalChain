public enum NotificationImportance : String, CaseIterable {
      
    case None = "None"
    case Min = "Min"
    case Low = "Low"
    case Default = "Default"
    case High = "High"
    case Max = "Max"
    
}
