public enum NotificationPrivacy : String, CaseIterable {
    
    case Public = "Public"
    case Secret = "Secret"
    case Private = "Private"
}
