//
//  AwesomeNotificationsExtension.swift
//  awesome_notifications
//
//  Created by CardaDev on 03/02/22.
//

import Foundation

public protocol AwesomeNotificationsExtension {
    static func initialize()
    func loadExternalExtensions()
}
